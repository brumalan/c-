// Animal.h
#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>

class Animal {
private:
    float peso;
    float altura;
    int idade;

public:
    Animal(float peso, float altura, int idade)
        : peso(peso), altura(altura), idade(idade) {}

    virtual ~Animal() {}

    // Getters
    float getPeso() const { return peso; }
    float getAltura() const { return altura; }
    int getIdade() const { return idade; }

    // Setters
    void setPeso(float novoPeso) { peso = novoPeso; }
    void setAltura(float novaAltura) { altura = novaAltura; }
    void setIdade(int novaIdade) { idade = novaIdade; }

    virtual std::string som() const = 0;
    virtual void emitirSom() const = 0;
};

#endif
