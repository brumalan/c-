// Gato.h
#ifndef GATO_H
#define GATO_H

#include "Mamifero.h"
#include <iostream> // Para std::cout e std::endl

class Gato : public Mamifero {
private:
    std::string nome;

public:
    Gato(float peso, float altura, int idade, int numeroPatas, const std::string& alimentacao, const std::string& habitat, const std::string& nome)
        : Mamifero(peso, altura, idade, numeroPatas, alimentacao, habitat), nome(nome) {}

    virtual ~Gato() {}

    // Getters
    std::string getNome() const { return nome; }

    // Setter
    void setNome(const std::string& novoNome) { nome = novoNome; }

    virtual std::string som() const override {
        return "Miado";
    }

    virtual void emitirSom() const override {
        std::cout << som() << std::endl;
    }

    // Método para exibir todos os dados do gato
    void exibirDados() const {
        std::cout << "================= EXIBINDO DADOS ====================== "<< std::endl;
        std::cout << "Nome: " << getNome() << std::endl;
        std::cout << "Peso: " << getPeso() << " kg" << std::endl;
        std::cout << "Altura: " << getAltura() << " m" << std::endl;
        std::cout << "Idade: " << getIdade() << " anos" << std::endl;
        std::cout << "Numero de patas: " << getNumeroPatas() << std::endl;
        std::cout << "Alimentacao: " << getAlimentacao() << std::endl;
        std::cout << "Habitat: " << getHabitat() << std::endl;
    }
};

#endif
