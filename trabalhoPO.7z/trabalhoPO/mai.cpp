// main.cpp
#include <iostream>
#include "Cachorro.h"
#include "Gato.h"
#include "Cavalo.h"
#include "Cobra.h"
#include "Lagarto.h"

int main() {
    //Instanciando 
    Cachorro meuCachorro(10.5, 0.5, 5, 4, "Carnivoro", "Domestico", "Rex");
    Gato meuGato(5.0, 0.3, 3, 4, "Carnivoro", "Domestico", "Garfield");
    Cavalo meuCavalo(400.0, 1.5, 8, 4, "Herbivoro", "Pasto", "Pe de Pano");
    Cobra minhaCobra(1.5, 0.1, 3, 0, "Carnivora", "Floresta", "Naja");
    Lagarto meuLagarto(0.5, 0.05, 2, 4, "Onivoro", "Savana", "Teiu");

    //Exibindo dados
    meuCachorro.exibirDados();
    meuGato.exibirDados();
    meuCavalo.exibirDados();
    minhaCobra.exibirDados();
    meuLagarto.exibirDados();

    //Metodo emitir som com polimorfismo de sobreposição
    std::cout << "========================== SONS DOS ANIMAIS ============================= " << std::endl;
    std::cout << "O cachorro faz: ";
    meuCachorro.emitirSom();
    std::cout << "O gato faz: ";
    meuGato.emitirSom();
    std::cout << "O cavalo faz: ";
    meuCavalo.emitirSom();
    std::cout << "A cobra faz: ";
    minhaCobra.emitirSom();
    std::cout << "O lagarto faz: ";
    meuLagarto.emitirSom();

    // Método interagir com o cachorro usando polimorfismo de sobrecarga
    std::cout << "========================== INTERAGINDO COM O CACHORRO ============================= " << std::endl;
    meuCachorro.interagir("brigar");
    meuCachorro.interagir("falar");
    meuCachorro.interagir("correr");

    return 0;
}
