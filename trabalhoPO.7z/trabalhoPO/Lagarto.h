// Lagarto.h
#ifndef LAGARTO_H
#define LAGARTO_H

#include "Reptil.h"
#include <iostream> // Para std::cout e std::endl

class Lagarto : public Reptil {
private:
    std::string nome;

public:
    Lagarto(float peso, float altura, int idade, int numeroPatas, const std::string& alimentacao, const std::string& habitat, const std::string& nome)
        : Reptil(peso, altura, idade, numeroPatas, alimentacao, habitat), nome(nome) {}

    virtual ~Lagarto() {}

    // Getter
    std::string getNome() const { return nome; }

    // Setter
    void setNome(const std::string& novoNome) { nome = novoNome; }

    virtual std::string som() const override {
        return "Sibilo ou grunhido de lagarto";
    }

    virtual void emitirSom() const override {
        std::cout << som() << std::endl;
    }

    // Método para exibir todos os dados do lagarto
    void exibirDados() const {
        std::cout << "Nome: " << getNome() << std::endl;
        Reptil::exibirDados(); // Chama o método da classe base Reptil para exibir os dados gerais
    }
};

#endif
