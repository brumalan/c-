// Reptil.h
#ifndef REPTIL_H
#define REPTIL_H

#include "Animal.h"
#include <iostream> // Para std::cout e std::endl

class Reptil : public Animal {
private:
    int numeroPatas;
    std::string alimentacao;
    std::string habitat;

public:
    Reptil(float peso, float altura, int idade, int numeroPatas, const std::string& alimentacao, const std::string& habitat)
        : Animal(peso, altura, idade), numeroPatas(numeroPatas), alimentacao(alimentacao), habitat(habitat) {}

    virtual ~Reptil() {}

    // Getters
    int getNumeroPatas() const { return numeroPatas; }
    std::string getAlimentacao() const { return alimentacao; }
    std::string getHabitat() const { return habitat; }

    // Setters
    void setNumeroPatas(int numPatas) { numeroPatas = numPatas; }
    void setAlimentacao(const std::string& novaAlimentacao) { alimentacao = novaAlimentacao; }
    void setHabitat(const std::string& novoHabitat) { habitat = novoHabitat; }

    virtual std::string som() const override {
        return "Som genérico de réptil";
    }

    virtual void emitirSom() const override {
        std::cout << som() << std::endl;
    }

    // Método para exibir todos os dados do réptil
    void exibirDados() const {
        std::cout << "================= EXIBINDO DADOS ====================== "<< std::endl;
        std::cout << "Peso: " << getPeso() << " kg" << std::endl;
        std::cout << "Altura: " << getAltura() << " m" << std::endl;
        std::cout << "Idade: " << getIdade() << " anos" << std::endl;
        std::cout << "Numero de patas: " << getNumeroPatas() << std::endl;
        std::cout << "Alimentacao: " << getAlimentacao() << std::endl;
        std::cout << "Habitat: " << getHabitat() << std::endl;
    }
};

#endif
