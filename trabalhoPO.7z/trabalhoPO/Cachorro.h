// Cachorro.h
#ifndef CACHORRO_H
#define CACHORRO_H

#include "Mamifero.h"
#include <iostream> // Para std::cout e std::endl
#include <algorithm> // Para std::transform
#include <cctype>    // Para std::tolower

class Cachorro : public Mamifero {
private:
    std::string nome;

public:
    Cachorro(float peso, float altura, int idade, int numeroPatas, const std::string& alimentacao, const std::string& habitat, const std::string& nome)
        : Mamifero(peso, altura, idade, numeroPatas, alimentacao, habitat), nome(nome) {}

    virtual ~Cachorro() {}

    // Getters
    std::string getNome() const { return nome; }

    // Setter
    void setNome(const std::string& novoNome) { nome = novoNome; }

    virtual std::string som() const override {
        return "Latido";
    }

    virtual void emitirSom() const override {
        std::cout << som() << std::endl;
    }

    // Método para interagir com o cachorro
    void interagir(const std::string& acao) const {
        std::string acaoLowerCase;
        acaoLowerCase.reserve(acao.size());
        std::transform(acao.begin(), acao.end(), std::back_inserter(acaoLowerCase),
                       [](unsigned char c){ return std::tolower(c); });

        // Comparação direta com strings em minúsculas
        if (acaoLowerCase == "brigar") {
            std::cout << "Cachorro rosna!" << std::endl;
        } else if (acaoLowerCase == "falar") {
            std::cout << "Cachorro abana o rabo!" << std::endl;
        } else {
            std::cout << "Acao desconhecida para o cachorro." << std::endl;
        }
    }

    // Método para exibir todos os dados do cachorro
    void exibirDados() const {
        std::cout << "================= EXIBINDO DADOS ====================== "<< std::endl;
        std::cout << "Nome: " << getNome() << std::endl;
        std::cout << "Peso: " << getPeso() << " kg" << std::endl;
        std::cout << "Altura: " << getAltura() << " m" << std::endl;
        std::cout << "Idade: " << getIdade() << " anos" << std::endl;
        std::cout << "Numero de patas: " << getNumeroPatas() << std::endl;
        std::cout << "Alimentacao: " << getAlimentacao() << std::endl;
        std::cout << "Habitat: " << getHabitat() << std::endl;
    }
};

#endif
