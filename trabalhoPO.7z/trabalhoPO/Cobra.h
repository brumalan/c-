// Cobra.h
#ifndef COBRA_H
#define COBRA_H

#include "Reptil.h"
#include <iostream> // Para std::cout e std::endl

class Cobra : public Reptil {
private:
    std::string nome;

public:
    Cobra(float peso, float altura, int idade, int numeroPatas, const std::string& alimentacao, const std::string& habitat, const std::string& nome)
        : Reptil(peso, altura, idade, numeroPatas, alimentacao, habitat), nome(nome) {}

    virtual ~Cobra() {}

    // Getters
    std::string getNome() const { return nome; }

    // Setter
    void setNome(const std::string& novoNome) { nome = novoNome; }

    virtual std::string som() const override {
        return "Sibilo";
    }

    virtual void emitirSom() const override {
        std::cout << som() << std::endl;
    }

    // Método para exibir todos os dados da cobra
    void exibirDados() const {
        std::cout << "================= EXIBINDO DADOS ====================== "<< std::endl;
        std::cout << "Nome: " << getNome() << std::endl;
        std::cout << "Peso: " << getPeso() << " kg" << std::endl;
        std::cout << "Altura: " << getAltura() << " m" << std::endl;
        std::cout << "Idade: " << getIdade() << " anos" << std::endl;
        std::cout << "Numero de patas: " << getNumeroPatas() << std::endl;
        std::cout << "Alimentacao: " << getAlimentacao() << std::endl;
        std::cout << "Habitat: " << getHabitat() << std::endl;
    }
};

#endif
