// Mamifero.h
#ifndef MAMIFERO_H
#define MAMIFERO_H

#include "Animal.h"

class Mamifero : public Animal {
private:
    int numeroPatas;
    std::string alimentacao;
    std::string habitat;

public:
    Mamifero(float peso, float altura, int idade, int numeroPatas, const std::string& alimentacao, const std::string& habitat)
        : Animal(peso, altura, idade), numeroPatas(numeroPatas), alimentacao(alimentacao), habitat(habitat) {}

    virtual ~Mamifero() {}

    // Getters
    int getNumeroPatas() const { return numeroPatas; }
    std::string getAlimentacao() const { return alimentacao; }
    std::string getHabitat() const { return habitat; }

    // Setters
    void setNumeroPatas(int numPatas) { numeroPatas = numPatas; }
    void setAlimentacao(const std::string& novaAlimentacao) { alimentacao = novaAlimentacao; }
    void setHabitat(const std::string& novoHabitat) { habitat = novoHabitat; }

    virtual std::string som() const override {
        return "Som de mamífero";
    }

    virtual void emitirSom() const override = 0; // Método puramente virtual
};

#endif
